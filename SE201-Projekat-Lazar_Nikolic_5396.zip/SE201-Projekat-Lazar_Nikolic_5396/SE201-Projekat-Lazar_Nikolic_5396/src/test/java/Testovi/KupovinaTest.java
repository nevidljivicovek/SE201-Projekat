/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Testovi;

import Klase.Kupovina;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lazar
 */


public class KupovinaTest {
    @Test
    public void testKupovinaCreation() {
        Kupovina kupovina = new Kupovina(1, 1, 12, "2024-06-14");
        assertEquals(1, kupovina.getId());
        assertEquals(1, kupovina.getKorisnikId());
        assertEquals(12.50, kupovina.getUkupnaCena());
        assertEquals("2024-06-14", kupovina.getDatum());
    }
}
