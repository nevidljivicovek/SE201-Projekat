/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Testovi;

import Klase.Film;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lazar
 */


public class FilmTest {
    @Test
    public void testFilmCreation() {
        Film film = new Film(1, "Inception", "Christopher Nolan", "Sci-Fi", 2010);
        assertEquals(1, film.getId());
        assertEquals("Inception", film.getNaziv());
        assertEquals("Christopher Nolan", film.getReziser());
        assertEquals("Sci-Fi", film.getZanr());
        assertEquals(2010, film.getGodina());
    }
}



