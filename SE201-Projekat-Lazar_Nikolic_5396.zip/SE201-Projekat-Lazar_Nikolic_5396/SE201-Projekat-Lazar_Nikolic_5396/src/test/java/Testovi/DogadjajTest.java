/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Testovi;

import Klase.Dogadjaj;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lazar
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DogadjajTest {
    @Test
    public void testDogadjajCreation() {
        Dogadjaj dogadjaj = new Dogadjaj(1, "Premijera","Opis","2024-06-15");
        assertEquals(1, dogadjaj.getId());
        assertEquals("Premijera", dogadjaj.getNaziv());
        assertEquals("2024-06-15", dogadjaj.getDatum());
    }
}


