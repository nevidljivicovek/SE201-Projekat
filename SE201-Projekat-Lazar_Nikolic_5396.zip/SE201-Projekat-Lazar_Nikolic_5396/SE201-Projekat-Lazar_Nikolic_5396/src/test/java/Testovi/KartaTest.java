/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Testovi;

import Klase.Karta;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lazar
 */


public class KartaTest {
    @Test
    public void testKartaCreation() {
        Karta karta = new Karta(1, 1, 1, 12.50);
        assertEquals(1, karta.getId());
        assertEquals(1, karta.getProjekcijaId());
        assertEquals(1, karta.getKorisnikId());
        assertEquals(12.50, karta.getCena());
    }
}


