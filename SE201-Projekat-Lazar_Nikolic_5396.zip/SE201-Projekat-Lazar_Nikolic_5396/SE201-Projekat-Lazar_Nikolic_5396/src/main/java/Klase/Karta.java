/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Karta {
    private int id;
    private int projekcijaId;
    private int korisnikId;
    private double cena;

    public Karta(int id, int projekcijaId, int korisnikId, double cena) {
        this.id = id;
        this.projekcijaId = projekcijaId;
        this.korisnikId = korisnikId;
        this.cena = cena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjekcijaId() {
        return projekcijaId;
    }

    public void setProjekcijaId(int projekcijaId) {
        this.projekcijaId = projekcijaId;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    @Override
    public String toString() {
        return "Karta{" +
                "id=" + id +
                ", projekcijaId=" + projekcijaId +
                ", korisnikId=" + korisnikId +
                ", cena=" + cena +
                '}';
    }
}

