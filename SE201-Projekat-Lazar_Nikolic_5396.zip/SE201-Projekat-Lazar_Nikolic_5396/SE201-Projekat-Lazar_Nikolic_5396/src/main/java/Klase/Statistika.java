/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Statistika {
    private int id;
    private int korisnikId;
    private int filmId;
    private int brojGledanja;

    public Statistika(int id, int korisnikId, int filmId, int brojGledanja) {
        this.id = id;
        this.korisnikId = korisnikId;
        this.filmId = filmId;
        this.brojGledanja = brojGledanja;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public int getFilmId() {
        return filmId;
    }

    public void setFilmId(int filmId) {
        this.filmId = filmId;
    }

    public int getBrojGledanja() {
        return brojGledanja;
    }

    public void setBrojGledanja(int brojGledanja) {
        this.brojGledanja = brojGledanja;
    }

    @Override
    public String toString() {
        return "Statistika{" +
                "id=" + id +
                ", korisnikId=" + korisnikId +
                ", filmId=" + filmId +
                ", brojGledanja=" + brojGledanja +
                '}';
    }
}

