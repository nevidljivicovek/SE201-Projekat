/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Prikaz {
    private int id;
    private int filmId;
    private int salaId;

    public Prikaz(int id, int filmId, int salaId) {
        this.id = id;
        this.filmId = filmId;
        this.salaId = salaId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFilmId() {
        return filmId;
    }

    public void setFilmId(int filmId) {
        this.filmId = filmId;
    }

    public int getSalaId() {
        return salaId;
    }

    public void setSalaId(int salaId) {
        this.salaId = salaId;
    }

    @Override
    public String toString() {
        return "Prikaz{" +
                "id=" + id +
                ", filmId=" + filmId +
                ", salaId=" + salaId +
                '}';
    }
}

