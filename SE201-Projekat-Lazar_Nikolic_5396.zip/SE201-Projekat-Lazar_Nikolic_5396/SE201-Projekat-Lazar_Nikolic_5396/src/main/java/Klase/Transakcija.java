/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Transakcija {
    private int id;
    private int korisnikId;
    private double iznos;
    private String datum;

    public Transakcija(int id, int korisnikId, double iznos, String datum) {
        this.id = id;
        this.korisnikId = korisnikId;
        this.iznos = iznos;
        this.datum = datum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public double getIznos() {
        return iznos;
    }

    public void setIznos(double iznos) {
        this.iznos = iznos;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    @Override
    public String toString() {
        return "Transakcija{" +
                "id=" + id +
                ", korisnikId=" + korisnikId +
                ", iznos=" + iznos +
                ", datum='" + datum + '\'' +
                '}';
    }
}

