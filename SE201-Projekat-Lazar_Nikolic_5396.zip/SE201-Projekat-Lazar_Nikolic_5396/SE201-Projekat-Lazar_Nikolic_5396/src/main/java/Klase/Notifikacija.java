/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Notifikacija {
    private int id;
    private int korisnikId;
    private String poruka;

    public Notifikacija(int id, int korisnikId, String poruka) {
        this.id = id;
        this.korisnikId = korisnikId;
        this.poruka = poruka;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    @Override
    public String toString() {
        return "Notifikacija{" +
                "id=" + id +
                ", korisnikId=" + korisnikId +
                ", poruka='" + poruka + '\'' +
                '}';
    }
}
