/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Rezervacija {
    private int id;
    private int projekcijaId;
    private int korisnikId;
    private int brojKarata;

    public Rezervacija(int id, int projekcijaId, int korisnikId, int brojKarata) {
        this.id = id;
        this.projekcijaId = projekcijaId;
        this.korisnikId = korisnikId;
        this.brojKarata = brojKarata;
    }

    public Rezervacija(int i, int i0, int i1, int i2, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjekcijaId() {
        return projekcijaId;
    }

    public void setProjekcijaId(int projekcijaId) {
        this.projekcijaId = projekcijaId;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public int getBrojKarata() {
        return brojKarata;
    }

    public void setBrojKarata(int brojKarata) {
        this.brojKarata = brojKarata;
    }

    @Override
    public String toString() {
        return "Rezervacija{" +
                "id=" + id +
                ", projekcijaId=" + projekcijaId +
                ", korisnikId=" + korisnikId +
                ", brojKarata=" + brojKarata +
                '}';
    }

    public Object getDatumRezervacije() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

