/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class KorisnickaPodrska {
    private String ime;
    private String email;
    private String poruka;

    public KorisnickaPodrska(String ime, String email, String poruka) {
        this.ime = ime;
        this.email = email;
        this.poruka = poruka;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    @Override
    public String toString() {
        return "KorisnickaPodrska{" +
                "ime='" + ime + '\'' +
                ", email='" + email + '\'' +
                ", poruka='" + poruka + '\'' +
                '}';
    }
}

