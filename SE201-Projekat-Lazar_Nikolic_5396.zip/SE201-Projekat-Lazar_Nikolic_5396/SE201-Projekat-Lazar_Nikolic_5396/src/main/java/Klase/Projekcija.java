/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Projekcija {
    private int id;
    private int filmId;
    private int salaId;
    private String datum;
    private String vreme;

    public Projekcija(int id, int filmId, int salaId, String datum, String vreme) {
        this.id = id;
        this.filmId = filmId;
        this.salaId = salaId;
        this.datum = datum;
        this.vreme = vreme;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFilmId() {
        return filmId;
    }

    public void setFilmId(int filmId) {
        this.filmId = filmId;
    }

    public int getSalaId() {
        return salaId;
    }

    public void setSalaId(int salaId) {
        this.salaId = salaId;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getVreme() {
        return vreme;
    }

    public void setVreme(String vreme) {
        this.vreme = vreme;
    }

    @Override
    public String toString() {
        return "Projekcija{" +
                "id=" + id +
                ", filmId=" + filmId +
                ", salaId=" + salaId +
                ", datum='" + datum + '\'' +
                ", vreme='" + vreme + '\'' +
                '}';
    }
}

