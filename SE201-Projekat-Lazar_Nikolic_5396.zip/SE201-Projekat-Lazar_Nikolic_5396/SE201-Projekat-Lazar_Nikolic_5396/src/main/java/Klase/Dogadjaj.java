/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Dogadjaj {
    private String naziv;
    private String opis;
    private String datum;

    public Dogadjaj(int id, String naziv, String opis, String datum) {
        this.naziv = naziv;
        this.opis = opis;
        this.datum = datum;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    @Override
    public String toString() {
        return "Dogadjaj{" +
                "naziv='" + naziv + '\'' +
                ", opis='" + opis + '\'' +
                ", datum='" + datum + '\'' +
                '}';
    }

    public short getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

