/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Sala {
    private int id;
    private String naziv;
    private int kapacitet;

    public Sala(int id, String naziv, int kapacitet) {
        this.id = id;
        this.naziv = naziv;
        this.kapacitet = kapacitet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getKapacitet() {
        return kapacitet;
    }

    public void setKapacitet(int kapacitet) {
        this.kapacitet = kapacitet;
    }

    @Override
    public String toString() {
        return "Sala{" +
                "id=" + id +
                ", naziv='" + naziv + '\'' +
                ", kapacitet=" + kapacitet +
                '}';
    }
}

