/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Kupovina {
    private int id;
    private int korisnikId;
    private int kartaId;
    private String datum;

    public Kupovina(int id, int korisnikId, int kartaId, String datum) {
        this.id = id;
        this.korisnikId = korisnikId;
        this.kartaId = kartaId;
        this.datum = datum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public int getKartaId() {
        return kartaId;
    }

    public void setKartaId(int kartaId) {
        this.kartaId = kartaId;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    @Override
    public String toString() {
        return "Kupovina{" +
                "id=" + id +
                ", korisnikId=" + korisnikId +
                ", kartaId=" + kartaId +
                ", datum='" + datum + '\'' +
                '}';
    }

    public double getUkupnaCena() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

