/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class Film {
    private String naziv;
    private String zanr;
    private String reziser;
    private int trajanje; // trajanje u minutima

    public Film(String naziv,String reziser, String zanr, int trajanje) {
        this.naziv = naziv;
        this.zanr = zanr;
        this.reziser= reziser;
        this.trajanje = trajanje;
    }

    public Film(int i, String inception, String christopher_Nolan, String sciFi, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNaziv() {
        return naziv;
    }
    

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }

    public int getTrajanje() {
        return trajanje;
    }

    public void setTrajanje(int trajanje) {
        this.trajanje = trajanje;
    }

    @Override
    public String toString() {
        return "Film{" +
                "naziv='" + naziv + '\'' +
                ", reziser=" + reziser +
                ", zanr='" + zanr + '\'' +
                ", trajanje=" + trajanje +
                '}';
    }

    public short getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    public Object getReziser() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public short getGodina() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
