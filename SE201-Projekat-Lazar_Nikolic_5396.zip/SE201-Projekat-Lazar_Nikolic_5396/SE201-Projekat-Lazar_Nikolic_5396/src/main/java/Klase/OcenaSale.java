/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Klase;

/**
 *
 * @author Lazar
 */
public class OcenaSale {
    private int id;
    private int salaId;
    private int korisnikId;
    private int ocena;

    public OcenaSale(int id, int salaId, int korisnikId, int ocena) {
        this.id = id;
        this.salaId = salaId;
        this.korisnikId = korisnikId;
        this.ocena = ocena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSalaId() {
        return salaId;
    }

    public void setSalaId(int salaId) {
        this.salaId = salaId;
    }

    public int getKorisnikId() {
        return korisnikId;
    }

    public void setKorisnikId(int korisnikId) {
        this.korisnikId = korisnikId;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    @Override
    public String toString() {
        return "OcenaSale{" +
                "id=" + id +
                ", salaId=" + salaId +
                ", korisnikId=" + korisnikId +
                ", ocena=" + ocena +
                '}';
    }
}

