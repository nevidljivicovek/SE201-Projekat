import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import java.util.*;

class Node {
    String name;
    List<Edge> edges;

    Node(String name) {
        this.name = name;
        this.edges = new ArrayList<>();
    }
}

class Edge {
    Node from;
    Node to;
    int weight;

    Edge(Node from, Node to, int weight) {
        this.from = from;
        this.to = to;
        this.weight = weight;
    }
}

class Graph {
    List<Node> nodes;

    Graph() {
        this.nodes = new ArrayList<>();
    }

    void addNode(Node node) {
        nodes.add(node);
    }

    void addEdge(Node from, Node to, int weight) {
        from.edges.add(new Edge(from, to, weight));
    }

    Map<Node, Integer> dijkstra(Node start) {
        Map<Node, Integer> distances = new HashMap<>();
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));

        for (Node node : nodes) {
            distances.put(node, Integer.MAX_VALUE);
        }
        distances.put(start, 0);
        pq.add(start);

        while (!pq.isEmpty()) {
            Node current = pq.poll();
            for (Edge edge : current.edges) {
                int newDist = distances.get(current) + edge.weight;
                if (newDist < distances.get(edge.to)) {
                    distances.put(edge.to, newDist);
                    pq.add(edge.to);
                }
            }
        }

        return distances;
    }

    Map<Node, Integer> bellmanFord(Node start) {
        Map<Node, Integer> distances = new HashMap<>();

        for (Node node : nodes) {
            distances.put(node, Integer.MAX_VALUE);
        }
        distances.put(start, 0);

        for (int i = 0; i < nodes.size() - 1; i++) {
            for (Node node : nodes) {
                for (Edge edge : node.edges) {
                    int newDist = distances.get(node) + edge.weight;
                    if (newDist < distances.get(edge.to)) {
                        distances.put(edge.to, newDist);
                    }
                }
            }
        }

        for (Node node : nodes) {
            for (Edge edge : node.edges) {
                if (distances.get(node) + edge.weight < distances.get(edge.to)) {
                    System.out.println("Graph contains a negative-weight cycle");
                }
            }
        }

        return distances;
    }
}

public class Main extends Application {
    private Graph graph;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Graph Visualization");

        Pane pane = new Pane();
        Scene scene = new Scene(pane, 800, 600);

        graph = createSampleGraph();

        drawGraph(pane);

        Button btn = new Button("Run Dijkstra");
        btn.setLayoutX(10);
        btn.setLayoutY(10);
        btn.setOnAction(event -> {
            Node startNode = graph.nodes.get(0); // Assume the first node as the start node
            Map<Node, Integer> distances = graph.dijkstra(startNode);
            displayDistances(distances, pane);
        });

        pane.getChildren().add(btn);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Graph createSampleGraph() {
        Graph graph = new Graph();

        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");

        graph.addNode(a);
        graph.addNode(b);
        graph.addNode(c);

        graph.addEdge(a, b, 4);
        graph.addEdge(a, c, 1);
        graph.addEdge(c, b, 2);

        return graph;
    }

    private void drawGraph(Pane pane) {
        Map<Node, Circle> nodeCircles = new HashMap<>();
        double centerX = 400;
        double centerY = 300;
        double radius = 150;

        int i = 0;
        for (Node node : graph.nodes) {
            double angle = 2 * Math.PI * i / graph.nodes.size();
            double x = centerX + radius * Math.cos(angle);
            double y = centerY + radius * Math.sin(angle);

            Circle circle = new Circle(x, y, 20, Color.LIGHTBLUE);
            Label label = new Label(node.name);
            label.setLayoutX(x - 5);
            label.setLayoutY(y - 10);

            nodeCircles.put(node, circle);

            pane.getChildren().addAll(circle, label);
            i++;
        }

        for (Node node : graph.nodes) {
            for (Edge edge : node.edges) {
                Circle fromCircle = nodeCircles.get(edge.from);
                Circle toCircle = nodeCircles.get(edge.to);

                Line line = new Line(fromCircle.getCenterX(), fromCircle.getCenterY(),
                        toCircle.getCenterX(), toCircle.getCenterY());
                line.setStrokeWidth(2);
                pane.getChildren().add(line);
            }
        }
    }

    private void displayDistances(Map<Node, Integer> distances, Pane pane) {
        double y = 40;
        for (Map.Entry<Node, Integer> entry : distances.entrySet()) {
            Label label = new Label("Distance from A to " + entry.getKey().name + " is " + entry.getValue());
            label.setLayoutX(10);
            label.setLayoutY(y);
            y += 20;
            pane.getChildren().add(label);
        }
    }
}
