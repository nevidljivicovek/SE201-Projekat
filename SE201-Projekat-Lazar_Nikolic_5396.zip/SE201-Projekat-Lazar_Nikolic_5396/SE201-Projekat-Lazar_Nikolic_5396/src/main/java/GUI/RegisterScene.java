/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Lazar
 */
import Klase.Korisnik;
import Konektor.DBConnection;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class RegisterScene extends Scene {
    private TextField usernameField;
    private PasswordField passwordField;
    private Button registerButton;

    public RegisterScene() {
        super(new VBox(), 400, 300);

        VBox root = (VBox) getRoot();
        root.getChildren().add(new Label("Register Page"));

        usernameField = new TextField();
        usernameField.setPromptText("Username");

        passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        registerButton = new Button("Register");

        registerButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                System.out.println("Morate uneti podatke.");
                // Možete dodati prikazivanje poruke korisniku da mora unijeti podatke
                return;
            }

            // Pravimo novi korisnik objekat
            Korisnik noviKorisnik = new Korisnik(username, password);
            
            // Pozivamo metodu za dodavanje korisnika u bazu
            boolean uspjesnoDodavanje = DBConnection.dodajKorisnika(noviKorisnik);

            if (uspjesnoDodavanje) {
                System.out.println("Uspešno ste se registrovali.");
                // Opcionalno, možete vratiti korisnika na login stranicu nakon uspešne registracije
                // primaryStage.setScene(loginScene);
            } else {
                System.out.println("Došlo je do greške pri registraciji.");
                // Ovdje dodajte logiku za prikaz greške ili slično
            }
        });

        root.getChildren().addAll(usernameField, passwordField, registerButton);
    }

    public TextField getUsernameField() {
        return usernameField;
    }

    public PasswordField getPasswordField() {
        return passwordField;
    }

    public Button getRegisterButton() {
        return registerButton;
    }

    Object getBackButton() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

