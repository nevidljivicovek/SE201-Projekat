/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package GUI;

import Klase.Korisnik;
import Konektor.DBConnection;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Lazar
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class iBioskop extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Dobrodošli u iBioskop");

        LoginScene loginScene = new LoginScene();
        RegisterScene registerScene = new RegisterScene();

        primaryStage.setScene(loginScene);

        loginScene.getRegisterButton().setOnAction(e -> {
            primaryStage.setScene(registerScene);
        });

        loginScene.getLoginButton().setOnAction(e -> {
            String username = loginScene.getUsernameField().getText().trim();
            String password = loginScene.getPasswordField().getText().trim();

            // Ovdje ide logika za provjeru korisničkog imena i lozinke
            // Primjer: provjera da li je korisničko ime "admin" i lozinka "admin"
            if (username.equals("admin") && password.equals("admin")) {
                System.out.println("Uspješno ste prijavljeni!");
                // Otvoriti novi prozor ili nastaviti sa radom
                primaryStage.close(); // Zatvoriti login prozor nakon uspješne prijave
            } else {
                System.out.println("Neuspješna prijava. Pokušajte ponovo.");
                // Dodati logiku za prikaz greške ili slično
            }
        });

        primaryStage.show();
    }
}