/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Lazar
 */
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class ReviewScene extends Scene {
    public ReviewScene() {
        super(new VBox(), 400, 300);

        VBox root = (VBox) getRoot();
        root.getChildren().add(new Label("Review Page"));

        // Add more UI components here
    }
}

