/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Konektor;

/**
 *
 * @author Lazar
 */

import Klase.Korisnik;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/ibioskopbaza";
    private static final String USERNAME = "root";
    private static final String PASSWORD = ""; // Promijenite ovo u vašu lozinku

    // Metoda za dodavanje novog korisnika u bazu
    public static boolean dodajKorisnika(Korisnik korisnik) {
        String sql = "INSERT INTO Korisnik (ime, prezime, email, lozinka) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, korisnik.getIme());
            stmt.setString(2, korisnik.getPrezime());
            stmt.setString(3, korisnik.getEmail());
            stmt.setString(4, korisnik.getLozinka());

            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.out.println("Došlo je do greške prilikom registracije korisnika.");
            e.printStackTrace();
            return false;
        }
    }

    public static Korisnik proveriKorisnika(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

